//Standard modules/requires
const express = require("express");
const app = express();
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const ejs = require("ejs");

app.use(bodyParser.urlencoded({extended:true}));
app.set('view engine', 'ejs');

// connect to Mongoose (password: pass123)
mongoose.connect("mongodb://todoAppUser:pass123@cluster0-shard-00-00.no3vk.mongodb.net:27017,cluster0-shard-00-01.no3vk.mongodb.net:27017,cluster0-shard-00-02.no3vk.mongodb.net:27017/Songs?ssl=true&replicaSet=atlas-gu7ilm-shard-0&authSource=admin&retryWrites=true&w=majority", {useNewUrlParser:true}, {useUnifiedtopology: true})

//Schema for DB
const notesSchema = {
    Title: String,
    Artist: String
}

const Note = mongoose.model("Note", notesSchema);

//App GET
// app.get("/", function(req, res){
//     res.render("index.ejs");
//     res.sendFile(__dirname + "/index.html")
// })


app.get("/", (req, res) => {
    Note.find({}, function(err, notes) {
        res.render("index.ejs", {
            notesList: notes
        })
    })
})


//App POST
app.post("/", function(req, res){
    let newNote = new Note({
        Title: req.body.title,
        Artist: req.body.artist,
    });
    newNote.save();
    res.redirect("/");
})

app.listen(3000, function(){
    console.log("Server is running on port 3000");
})